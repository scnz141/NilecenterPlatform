# Nile Center Learning Platform - Design Brainstorm

## Three Stylistic Approaches

### 1. "Oasis Scholastica" — Desert Modernism meets Digital Learning
A warm, earth-toned interface inspired by Egyptian architecture and the Nile's flowing geometry. Combines terracotta, sand, and deep teal with flowing organic shapes.
**Probability:** 0.04

### 2. "Meridian" — Structured Swiss Precision with Warm Accents
A clean, grid-heavy interface using a strict typographic hierarchy, monochromatic base with a single bold accent color. Inspired by Swiss/International design but warmed with golden amber highlights.
**Probability:** 0.06

### 3. "Lumina" — Glassmorphism-infused Knowledge Platform
A contemporary interface using frosted glass panels, soft gradients, and luminous accent colors. Light and airy with depth created through layered translucent surfaces.
**Probability:** 0.03

---

## Chosen Approach: "Oasis Scholastica" — Desert Modernism meets Digital Learning

### Design Movement
Neo-Egyptian Modernism — drawing from the geometry of Islamic patterns, the warmth of Nile Valley earth tones, and the precision of modern digital interfaces. This is NOT a themed novelty; it's a sophisticated fusion that feels both culturally rooted and forward-looking.

### Core Principles
1. **Flowing Geometry:** Curved containers and asymmetric layouts inspired by the Nile's path — nothing feels boxy or rigid.
2. **Warm Authority:** Deep, confident colors that convey academic seriousness without coldness.
3. **Layered Depth:** Multiple visual planes using shadows and subtle elevation to create a sense of architectural space.
4. **Purposeful Negative Space:** Content breathes; density is managed through progressive disclosure.

### Color Philosophy
The palette draws from the Egyptian landscape at golden hour — when the Nile reflects warm amber light against deep teal waters and terracotta buildings.
- **Primary:** Deep Teal `#0F4C5C` — the depth of the Nile, used for navigation and primary actions
- **Secondary:** Warm Amber `#E8A838` — golden accents for highlights, CTAs, and active states
- **Background:** Warm Sand `#FAF6F0` — not cold white, but the warmth of papyrus
- **Surface:** Soft Cream `#FFFFFF` with warm shadows
- **Text Primary:** Deep Charcoal `#1A1A2E` — near-black with warmth
- **Text Secondary:** Warm Gray `#6B6B7B`
- **Success:** Olive Green `#4A7C59`
- **Accent:** Terracotta `#C75B39` — for alerts and important markers

### Layout Paradigm
Asymmetric dashboard with a persistent left sidebar that uses a slightly curved right edge. Main content area uses a card-based system with varied card sizes creating visual rhythm. The top area features a wide, gently curved header that flows into the content below.

### Signature Elements
1. **Flowing Dividers:** Section separators use gentle wave/curve shapes instead of straight lines, echoing the Nile's flow.
2. **Geometric Accent Patterns:** Subtle Islamic geometric patterns used as background textures in headers and empty states.
3. **Warm Glow Shadows:** All elevated elements use warm-toned shadows (amber-tinted) instead of cold gray shadows.

### Interaction Philosophy
Interactions feel like water flowing — smooth, continuous, and natural. Hover states expand gently, transitions use ease-out curves, and elements appear to rise toward the user rather than snap into place.

### Animation
- Page transitions: 250ms ease-out with subtle vertical slide (8px)
- Card hover: 180ms scale(1.02) with warm shadow expansion
- Sidebar items: 150ms background-color transition with left-border reveal
- Data loading: Skeleton shimmer using warm gradient (sand to cream)
- Modal entry: 300ms from scale(0.95) + opacity with backdrop blur
- Stagger delay: 50ms per item for list reveals

### Typography System
- **Display/Headlines:** "Playfair Display" — serif with character, used for page titles and hero text
- **Body/UI:** "Inter" at 400/500/600 weights — clean and highly readable
- **Monospace/Data:** "JetBrains Mono" — for grades, IDs, and numerical data
- Hierarchy: Display 2.5rem → H1 2rem → H2 1.5rem → H3 1.25rem → Body 1rem → Small 0.875rem

### Brand Essence
**Nile Center: Where ancient wisdom meets modern learning** — for international students seeking authentic Arabic, Quran, and language education through a platform that respects tradition while embracing technology.
Personality: **Scholarly, Warm, Confident**

### Brand Voice
Headlines sound authoritative yet inviting: "Your Journey Through Knowledge Begins Here" and "Master Arabic with Scholars Who Care." CTAs are direct and encouraging: "Begin Your Path" / "Explore Courses" / "View Your Progress." Microcopy is helpful and human: "We'll get you set up in moments" / "Your learning awaits."

### Wordmark & Logo
A stylized "NC" monogram where the N flows into the C like water, with a subtle crescent/dome shape integrated into the negative space. Bold, geometric, and instantly recognizable — rendered in deep teal on light backgrounds, warm amber on dark.

### Signature Brand Color
**Deep Teal `#0F4C5C`** — this is unmistakably Nile Center's color. It appears in the sidebar, primary buttons, and navigation. It evokes the depth of the Nile while maintaining professional gravitas.
