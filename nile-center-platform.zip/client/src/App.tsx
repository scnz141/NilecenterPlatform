import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Public
import Home from "./pages/Home";
import Login from "./pages/Login";

// Admin / Head of Department
import Dashboard from "./pages/Dashboard";
import Courses from "./pages/Courses";
import Students from "./pages/Students";
import Classes from "./pages/Classes";
import Users from "./pages/Users";
import Messages from "./pages/Messages";
import Payments from "./pages/Payments";
import Reports from "./pages/Reports";
import Schedule from "./pages/Schedule";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";
import Settings from "./pages/Settings";

// Student Portal
import StudentDashboard from "./pages/student/StudentDashboard";
import StudentCourses from "./pages/student/StudentCourses";
import StudentGrades from "./pages/student/StudentGrades";
import StudentAttendance from "./pages/student/StudentAttendance";
import StudentSchedule from "./pages/student/StudentSchedule";

// Teacher Portal
import TeacherDashboard from "./pages/teacher/TeacherDashboard";
import TeacherClasses from "./pages/teacher/TeacherClasses";
import TeacherAttendance from "./pages/teacher/TeacherAttendance";
import TeacherScores from "./pages/teacher/TeacherScores";
import TeacherSchedule from "./pages/teacher/TeacherSchedule";

// Registrar Portal
import RegistrarDashboard from "./pages/registrar/RegistrarDashboard";
import RegisterStudent from "./pages/registrar/RegisterStudent";
import PendingEnrollment from "./pages/registrar/PendingEnrollment";
import RegistrarPayments from "./pages/registrar/RegistrarPayments";

function Router() {
  return (
    <Switch>
      {/* Public */}
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />

      {/* Admin / Head of Department */}
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/courses" component={Courses} />
      <Route path="/students" component={Students} />
      <Route path="/classes" component={Classes} />
      <Route path="/users" component={Users} />
      <Route path="/messages" component={Messages} />
      <Route path="/payments" component={Payments} />
      <Route path="/reports" component={Reports} />
      <Route path="/schedule" component={Schedule} />
      <Route path="/profile" component={Profile} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/settings" component={Settings} />

      {/* Student Portal */}
      <Route path="/student" component={StudentDashboard} />
      <Route path="/student/courses" component={StudentCourses} />
      <Route path="/student/grades" component={StudentGrades} />
      <Route path="/student/attendance" component={StudentAttendance} />
      <Route path="/student/schedule" component={StudentSchedule} />

      {/* Teacher Portal */}
      <Route path="/teacher" component={TeacherDashboard} />
      <Route path="/teacher/classes" component={TeacherClasses} />
      <Route path="/teacher/attendance" component={TeacherAttendance} />
      <Route path="/teacher/scores" component={TeacherScores} />
      <Route path="/teacher/schedule" component={TeacherSchedule} />

      {/* Registrar Portal */}
      <Route path="/registrar" component={RegistrarDashboard} />
      <Route path="/registrar/register" component={RegisterStudent} />
      <Route path="/registrar/pending" component={PendingEnrollment} />
      <Route path="/registrar/payments" component={RegistrarPayments} />

      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
