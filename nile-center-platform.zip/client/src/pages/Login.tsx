import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Eye, EyeOff, ArrowRight, Globe } from "lucide-react";
import { toast } from "sonner";

const ROLES = [
  { id: "headofdepartment", label: "Head of Dept", color: "#3B82F6", route: "/dashboard", desc: "Full admin access" },
  { id: "registrar", label: "Registrar", color: "#8B5CF6", route: "/registrar", desc: "Enrollment & payments" },
  { id: "branchadmin", label: "Branch Admin", color: "#10B981", route: "/dashboard", desc: "Branch management" },
  { id: "teacher", label: "Teacher", color: "#F59E0B", route: "/teacher", desc: "Classes & grades" },
  { id: "accountant", label: "Accountant", color: "#EF4444", route: "/payments", desc: "Financial reports" },
  { id: "student", label: "Student", color: "#06B6D4", route: "/student", desc: "Courses & schedule" },
];

export default function Login() {
  const [, navigate] = useLocation();
  const [email, setEmail] = useState("eslamelnaggar85@yahoo.com");
  const [password, setPassword] = useState("12345");
  const [showPass, setShowPass] = useState(false);
  const [role, setRole] = useState("headofdepartment");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    setLoading(false);
    const selectedRoleData = ROLES.find(r => r.id === role);
    toast.success(`Signed in as ${selectedRoleData?.label}`);
    navigate(selectedRoleData?.route || "/dashboard");
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", background: "var(--background)", fontFamily: "'Inter', -apple-system, sans-serif" }}>
      {/* Left panel */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "48px 32px" }}>
        <div style={{ width: "100%", maxWidth: 360 }}>
          {/* Logo */}
          <Link href="/">
            <a style={{ display: "inline-flex", alignItems: "center", gap: 8, textDecoration: "none", marginBottom: 40 }}>
              <div style={{ width: 26, height: 26, borderRadius: 7, background: "var(--foreground)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span style={{ fontSize: 10, fontWeight: 800, color: "var(--background)" }}>NC</span>
              </div>
              <span style={{ fontSize: 14, fontWeight: 600, color: "var(--foreground)", letterSpacing: "-0.02em" }}>Nile Center</span>
            </a>
          </Link>

          <h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: "-0.03em", color: "var(--foreground)", marginBottom: 6 }}>
            Welcome back
          </h1>
          <p style={{ fontSize: 14, color: "var(--muted-foreground)", marginBottom: 28 }}>
            Sign in to your account to continue
          </p>

          {/* Role selector */}
          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase", color: "var(--muted-foreground)", display: "block", marginBottom: 8 }}>
              Role
            </label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6 }}>
              {ROLES.map(r => (
                <button key={r.id} onClick={() => setRole(r.id)} style={{
                  padding: "7px 8px", borderRadius: 6, fontSize: 11, fontWeight: 500, cursor: "pointer", border: "1px solid",
                  transition: "all 100ms",
                  borderColor: role === r.id ? r.color : "var(--border)",
                  background: role === r.id ? r.color + "14" : "transparent",
                  color: role === r.id ? r.color : "var(--muted-foreground)",
                  textAlign: "left",
                }}>
                  <div>{r.label}</div>
                  <div style={{ fontSize: 9, opacity: 0.7, marginTop: 1 }}>{r.desc}</div>
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 500, color: "var(--foreground)", display: "block", marginBottom: 6 }}>Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                style={{ width: "100%", padding: "8px 12px", border: "1px solid var(--border)", borderRadius: 6, fontSize: 13, color: "var(--foreground)", background: "var(--background)", outline: "none", transition: "border-color 120ms", boxSizing: "border-box" }}
                onFocus={e => { (e.target as HTMLInputElement).style.borderColor = "var(--foreground)"; }}
                onBlur={e => { (e.target as HTMLInputElement).style.borderColor = "var(--border)"; }}
              />
            </div>

            <div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                <label style={{ fontSize: 12, fontWeight: 500, color: "var(--foreground)" }}>Password</label>
                <a href="#" style={{ fontSize: 12, color: "var(--muted-foreground)", textDecoration: "none" }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "var(--foreground)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "var(--muted-foreground)"; }}
                >Forgot?</a>
              </div>
              <div style={{ position: "relative" }}>
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  style={{ width: "100%", padding: "8px 36px 8px 12px", border: "1px solid var(--border)", borderRadius: 6, fontSize: 13, color: "var(--foreground)", background: "var(--background)", outline: "none", transition: "border-color 120ms", boxSizing: "border-box" }}
                  onFocus={e => { (e.target as HTMLInputElement).style.borderColor = "var(--foreground)"; }}
                  onBlur={e => { (e.target as HTMLInputElement).style.borderColor = "var(--border)"; }}
                />
                <button type="button" onClick={() => setShowPass(!showPass)} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "var(--muted-foreground)", display: "flex" }}>
                  {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} style={{
              width: "100%", padding: "9px", background: "var(--foreground)", color: "var(--background)", border: "none", borderRadius: 7, fontSize: 14, fontWeight: 500, cursor: loading ? "not-allowed" : "pointer",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 4,
              opacity: loading ? 0.7 : 1, transition: "opacity 120ms",
            }}>
              {loading ? (
                <span style={{ width: 14, height: 14, border: "2px solid var(--background)", borderTopColor: "transparent", borderRadius: "50%", display: "inline-block", animation: "spin 0.6s linear infinite" }} />
              ) : (
                <><span>Sign In</span><ArrowRight size={14} /></>
              )}
            </button>
          </form>

          <div style={{ marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--border)" }}>
            <a href="https://nilecenter.online" target="_blank" rel="noopener noreferrer" style={{
              display: "flex", alignItems: "center", gap: 8, padding: "9px 14px", border: "1px solid var(--border)", borderRadius: 7, fontSize: 13, color: "var(--foreground)", textDecoration: "none", transition: "background 100ms",
            }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "var(--muted)"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
            >
              <Globe size={15} />
              <span>Continue to Moodle LMS</span>
              <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--muted-foreground)" }}>↗</span>
            </a>
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div style={{ flex: 1, background: "var(--foreground)", display: "none", flexDirection: "column", justifyContent: "flex-end", padding: 48 }} className="lg:flex">
        <div>
          <div style={{ display: "flex", gap: 8, marginBottom: 32 }}>
            {["Arabic", "Quran", "Islamic Studies", "Turkish", "English"].map(tag => (
              <span key={tag} style={{ padding: "4px 10px", borderRadius: 99, border: "1px solid oklch(1 0 0 / 0.15)", fontSize: 12, color: "oklch(1 0 0 / 0.6)" }}>{tag}</span>
            ))}
          </div>
          <h2 style={{ fontSize: 36, fontWeight: 700, letterSpacing: "-0.03em", color: "white", lineHeight: 1.2, marginBottom: 16 }}>
            Education that<br />transcends borders
          </h2>
          <p style={{ fontSize: 15, color: "oklch(1 0 0 / 0.55)", lineHeight: 1.65, maxWidth: 380 }}>
            Nile Center connects students worldwide with authentic Arabic language and Islamic education — through a modern, integrated learning platform.
          </p>
          <div style={{ display: "flex", gap: 24, marginTop: 40, paddingTop: 32, borderTop: "1px solid oklch(1 0 0 / 0.1)" }}>
            {[{ v: "5,000+", l: "Students" }, { v: "295+", l: "Courses" }, { v: "3", l: "Branches" }].map(s => (
              <div key={s.l}>
                <div style={{ fontSize: 22, fontWeight: 700, color: "white" }}>{s.v}</div>
                <div style={{ fontSize: 12, color: "oklch(1 0 0 / 0.45)", marginTop: 2 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
